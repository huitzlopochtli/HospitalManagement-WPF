﻿namespace HospitalManagement
{
    partial class registerProfileUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.RoomWordLabel = new MetroFramework.Controls.MetroLabel();
            this.DutyTimeLabel = new MetroFramework.Controls.MetroLabel();
            this.DesignationLabel = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.PersonalPhoneLabel = new MetroFramework.Controls.MetroLabel();
            this.HomePhoneLabel = new MetroFramework.Controls.MetroLabel();
            this.DateOfBirthLabel = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.UserNameLabel = new MetroFramework.Controls.MetroLabel();
            this.OfficePhoneLabel = new MetroFramework.Controls.MetroLabel();
            this.GenderLabel = new MetroFramework.Controls.MetroLabel();
            this.LastNameLabel = new MetroFramework.Controls.MetroLabel();
            this.FirstNameLabel = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.metroTextBox1);
            this.metroPanel1.Controls.Add(this.metroLabel11);
            this.metroPanel1.Controls.Add(this.metroLabel14);
            this.metroPanel1.Controls.Add(this.metroLabel15);
            this.metroPanel1.Controls.Add(this.RoomWordLabel);
            this.metroPanel1.Controls.Add(this.DutyTimeLabel);
            this.metroPanel1.Controls.Add(this.DesignationLabel);
            this.metroPanel1.Controls.Add(this.metroLabel13);
            this.metroPanel1.Controls.Add(this.metroLabel12);
            this.metroPanel1.Controls.Add(this.metroLabel7);
            this.metroPanel1.Controls.Add(this.metroLabel10);
            this.metroPanel1.Controls.Add(this.PersonalPhoneLabel);
            this.metroPanel1.Controls.Add(this.HomePhoneLabel);
            this.metroPanel1.Controls.Add(this.DateOfBirthLabel);
            this.metroPanel1.Controls.Add(this.metroLabel8);
            this.metroPanel1.Controls.Add(this.UserNameLabel);
            this.metroPanel1.Controls.Add(this.OfficePhoneLabel);
            this.metroPanel1.Controls.Add(this.GenderLabel);
            this.metroPanel1.Controls.Add(this.LastNameLabel);
            this.metroPanel1.Controls.Add(this.FirstNameLabel);
            this.metroPanel1.Controls.Add(this.metroLabel9);
            this.metroPanel1.Controls.Add(this.metroLabel6);
            this.metroPanel1.Controls.Add(this.metroLabel5);
            this.metroPanel1.Controls.Add(this.metroLabel4);
            this.metroPanel1.Controls.Add(this.metroLabel3);
            this.metroPanel1.Controls.Add(this.metroLabel2);
            this.metroPanel1.Controls.Add(this.metroLabel1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(0, 0);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(1148, 552);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.Image = null;
            this.metroTextBox1.CustomButton.Location = new System.Drawing.Point(48, 2);
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = new System.Drawing.Size(105, 105);
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = 1;
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = false;
            this.metroTextBox1.Lines = new string[0];
            this.metroTextBox1.Location = new System.Drawing.Point(710, 144);
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ReadOnly = true;
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.Size = new System.Drawing.Size(156, 110);
            this.metroTextBox1.Style = MetroFramework.MetroColorStyle.Green;
            this.metroTextBox1.TabIndex = 82;
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel11.Location = new System.Drawing.Point(213, 297);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(82, 25);
            this.metroLabel11.TabIndex = 81;
            this.metroLabel11.Text = "Personal:";
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel14.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel14.Location = new System.Drawing.Point(230, 261);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(65, 25);
            this.metroLabel14.TabIndex = 80;
            this.metroLabel14.Text = "Home:";
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel15.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel15.Location = new System.Drawing.Point(227, 225);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(68, 25);
            this.metroLabel15.TabIndex = 79;
            this.metroLabel15.Text = "Office: ";
            // 
            // RoomWordLabel
            // 
            this.RoomWordLabel.AutoSize = true;
            this.RoomWordLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.RoomWordLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.RoomWordLabel.Location = new System.Drawing.Point(710, 109);
            this.RoomWordLabel.Name = "RoomWordLabel";
            this.RoomWordLabel.Size = new System.Drawing.Size(95, 25);
            this.RoomWordLabel.TabIndex = 78;
            this.RoomWordLabel.Text = "roomward";
            // 
            // DutyTimeLabel
            // 
            this.DutyTimeLabel.AutoSize = true;
            this.DutyTimeLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.DutyTimeLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.DutyTimeLabel.Location = new System.Drawing.Point(710, 74);
            this.DutyTimeLabel.Name = "DutyTimeLabel";
            this.DutyTimeLabel.Size = new System.Drawing.Size(83, 25);
            this.DutyTimeLabel.TabIndex = 77;
            this.DutyTimeLabel.Text = "dutytime";
            // 
            // DesignationLabel
            // 
            this.DesignationLabel.AutoSize = true;
            this.DesignationLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.DesignationLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.DesignationLabel.Location = new System.Drawing.Point(710, 39);
            this.DesignationLabel.Name = "DesignationLabel";
            this.DesignationLabel.Size = new System.Drawing.Size(105, 25);
            this.DesignationLabel.TabIndex = 76;
            this.DesignationLabel.Text = "designation";
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel13.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel13.Location = new System.Drawing.Point(581, 109);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(113, 25);
            this.metroLabel13.TabIndex = 75;
            this.metroLabel13.Text = "Room/Ward:";
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel12.Location = new System.Drawing.Point(613, 144);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(81, 25);
            this.metroLabel12.TabIndex = 74;
            this.metroLabel12.Text = "Address:";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel7.Location = new System.Drawing.Point(597, 74);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(97, 25);
            this.metroLabel7.TabIndex = 73;
            this.metroLabel7.Text = "Duty Time:";
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel10.Location = new System.Drawing.Point(583, 39);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(111, 25);
            this.metroLabel10.TabIndex = 72;
            this.metroLabel10.Text = "Designation:";
            // 
            // PersonalPhoneLabel
            // 
            this.PersonalPhoneLabel.AutoSize = true;
            this.PersonalPhoneLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.PersonalPhoneLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.PersonalPhoneLabel.Location = new System.Drawing.Point(302, 297);
            this.PersonalPhoneLabel.Name = "PersonalPhoneLabel";
            this.PersonalPhoneLabel.Size = new System.Drawing.Size(45, 25);
            this.PersonalPhoneLabel.TabIndex = 71;
            this.PersonalPhoneLabel.Text = "ppp";
            // 
            // HomePhoneLabel
            // 
            this.HomePhoneLabel.AutoSize = true;
            this.HomePhoneLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.HomePhoneLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.HomePhoneLabel.Location = new System.Drawing.Point(302, 261);
            this.HomePhoneLabel.Name = "HomePhoneLabel";
            this.HomePhoneLabel.Size = new System.Drawing.Size(42, 25);
            this.HomePhoneLabel.TabIndex = 70;
            this.HomePhoneLabel.Text = "hhh";
            // 
            // DateOfBirthLabel
            // 
            this.DateOfBirthLabel.AutoSize = true;
            this.DateOfBirthLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.DateOfBirthLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.DateOfBirthLabel.Location = new System.Drawing.Point(302, 138);
            this.DateOfBirthLabel.Name = "DateOfBirthLabel";
            this.DateOfBirthLabel.Size = new System.Drawing.Size(101, 25);
            this.DateOfBirthLabel.TabIndex = 69;
            this.DateOfBirthLabel.Text = "dateofbirth";
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel8.Location = new System.Drawing.Point(302, 333);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(54, 25);
            this.metroLabel8.TabIndex = 68;
            this.metroLabel8.Text = "email";
            // 
            // UserNameLabel
            // 
            this.UserNameLabel.AutoSize = true;
            this.UserNameLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.UserNameLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.UserNameLabel.Location = new System.Drawing.Point(302, 39);
            this.UserNameLabel.Name = "UserNameLabel";
            this.UserNameLabel.Size = new System.Drawing.Size(89, 25);
            this.UserNameLabel.TabIndex = 67;
            this.UserNameLabel.Text = "username";
            this.UserNameLabel.Click += new System.EventHandler(this.UserNameLabel_Click);
            // 
            // OfficePhoneLabel
            // 
            this.OfficePhoneLabel.AutoSize = true;
            this.OfficePhoneLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.OfficePhoneLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.OfficePhoneLabel.Location = new System.Drawing.Point(302, 225);
            this.OfficePhoneLabel.Name = "OfficePhoneLabel";
            this.OfficePhoneLabel.Size = new System.Drawing.Size(34, 25);
            this.OfficePhoneLabel.TabIndex = 66;
            this.OfficePhoneLabel.Text = "oo";
            // 
            // GenderLabel
            // 
            this.GenderLabel.AutoSize = true;
            this.GenderLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.GenderLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.GenderLabel.Location = new System.Drawing.Point(302, 171);
            this.GenderLabel.Name = "GenderLabel";
            this.GenderLabel.Size = new System.Drawing.Size(68, 25);
            this.GenderLabel.TabIndex = 65;
            this.GenderLabel.Text = "gender";
            // 
            // LastNameLabel
            // 
            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.LastNameLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.LastNameLabel.Location = new System.Drawing.Point(302, 105);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(83, 25);
            this.LastNameLabel.TabIndex = 64;
            this.LastNameLabel.Text = "lastname";
            // 
            // FirstNameLabel
            // 
            this.FirstNameLabel.AutoSize = true;
            this.FirstNameLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.FirstNameLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.FirstNameLabel.Location = new System.Drawing.Point(302, 72);
            this.FirstNameLabel.Name = "FirstNameLabel";
            this.FirstNameLabel.Size = new System.Drawing.Size(86, 25);
            this.FirstNameLabel.TabIndex = 63;
            this.FirstNameLabel.Text = "firstname";
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel9.Location = new System.Drawing.Point(180, 138);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(116, 25);
            this.metroLabel9.TabIndex = 62;
            this.metroLabel9.Text = "Date of Birth:";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(238, 333);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(58, 25);
            this.metroLabel6.TabIndex = 61;
            this.metroLabel6.Text = "Email:";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(200, 39);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(95, 25);
            this.metroLabel5.TabIndex = 60;
            this.metroLabel5.Text = "Username:";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(180, 200);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(66, 25);
            this.metroLabel4.TabIndex = 59;
            this.metroLabel4.Text = "Phone:";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(223, 171);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(73, 25);
            this.metroLabel3.TabIndex = 58;
            this.metroLabel3.Text = "Gender:";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(197, 105);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(99, 25);
            this.metroLabel2.TabIndex = 57;
            this.metroLabel2.Text = "Last Name:";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(195, 72);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(101, 25);
            this.metroLabel1.TabIndex = 56;
            this.metroLabel1.Text = "First Name:";
            // 
            // registerProfileUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.metroPanel1);
            this.Name = "registerProfileUserControl";
            this.Size = new System.Drawing.Size(1148, 552);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel RoomWordLabel;
        private MetroFramework.Controls.MetroLabel DutyTimeLabel;
        private MetroFramework.Controls.MetroLabel DesignationLabel;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel PersonalPhoneLabel;
        private MetroFramework.Controls.MetroLabel HomePhoneLabel;
        private MetroFramework.Controls.MetroLabel DateOfBirthLabel;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel UserNameLabel;
        private MetroFramework.Controls.MetroLabel OfficePhoneLabel;
        private MetroFramework.Controls.MetroLabel GenderLabel;
        private MetroFramework.Controls.MetroLabel LastNameLabel;
        private MetroFramework.Controls.MetroLabel FirstNameLabel;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
    }
}
