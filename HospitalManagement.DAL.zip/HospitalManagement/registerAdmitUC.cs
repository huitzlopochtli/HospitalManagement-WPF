﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalManagement
{
    public partial class registerAdmitUC : UserControl
    {
        public registerAdmitUC()
        {
            InitializeComponent();
        }

        private void metroLabel10_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel13_Click(object sender, EventArgs e)
        {

        }

        private void addressTextBox_Click(object sender, EventArgs e)
        {

        }
    }
}
