﻿namespace HospitalManagement
{
    partial class doctorProfileUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.degreesButton = new MetroFramework.Controls.MetroLabel();
            this.specialistOnButton = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.RoomWordLabel = new MetroFramework.Controls.MetroLabel();
            this.DutyTimeLabel = new MetroFramework.Controls.MetroLabel();
            this.DesignationLabel = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.PersonalPhoneLabel = new MetroFramework.Controls.MetroLabel();
            this.HomePhoneLabel = new MetroFramework.Controls.MetroLabel();
            this.DateOfBirthLabel = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.UserNameLabel = new MetroFramework.Controls.MetroLabel();
            this.OfficePhoneLabel = new MetroFramework.Controls.MetroLabel();
            this.GenderLabel = new MetroFramework.Controls.MetroLabel();
            this.LastNameLabel = new MetroFramework.Controls.MetroLabel();
            this.FirstNameLabel = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.metroLabel17);
            this.metroPanel1.Controls.Add(this.metroLabel16);
            this.metroPanel1.Controls.Add(this.degreesButton);
            this.metroPanel1.Controls.Add(this.specialistOnButton);
            this.metroPanel1.Controls.Add(this.metroTextBox1);
            this.metroPanel1.Controls.Add(this.metroLabel11);
            this.metroPanel1.Controls.Add(this.metroLabel14);
            this.metroPanel1.Controls.Add(this.metroLabel15);
            this.metroPanel1.Controls.Add(this.RoomWordLabel);
            this.metroPanel1.Controls.Add(this.DutyTimeLabel);
            this.metroPanel1.Controls.Add(this.DesignationLabel);
            this.metroPanel1.Controls.Add(this.metroLabel13);
            this.metroPanel1.Controls.Add(this.metroLabel12);
            this.metroPanel1.Controls.Add(this.metroLabel7);
            this.metroPanel1.Controls.Add(this.metroLabel10);
            this.metroPanel1.Controls.Add(this.PersonalPhoneLabel);
            this.metroPanel1.Controls.Add(this.HomePhoneLabel);
            this.metroPanel1.Controls.Add(this.DateOfBirthLabel);
            this.metroPanel1.Controls.Add(this.metroLabel8);
            this.metroPanel1.Controls.Add(this.UserNameLabel);
            this.metroPanel1.Controls.Add(this.OfficePhoneLabel);
            this.metroPanel1.Controls.Add(this.GenderLabel);
            this.metroPanel1.Controls.Add(this.LastNameLabel);
            this.metroPanel1.Controls.Add(this.FirstNameLabel);
            this.metroPanel1.Controls.Add(this.metroLabel9);
            this.metroPanel1.Controls.Add(this.metroLabel6);
            this.metroPanel1.Controls.Add(this.metroLabel5);
            this.metroPanel1.Controls.Add(this.metroLabel4);
            this.metroPanel1.Controls.Add(this.metroLabel3);
            this.metroPanel1.Controls.Add(this.metroLabel2);
            this.metroPanel1.Controls.Add(this.metroLabel1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(0, 0);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(1148, 552);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            this.metroPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel1_Paint);
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel17.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel17.Location = new System.Drawing.Point(635, 296);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(81, 25);
            this.metroLabel17.TabIndex = 113;
            this.metroLabel17.Text = "Degrees:";
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel16.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel16.Location = new System.Drawing.Point(598, 260);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(118, 25);
            this.metroLabel16.TabIndex = 112;
            this.metroLabel16.Text = "Specialist On:";
            // 
            // degreesButton
            // 
            this.degreesButton.AutoSize = true;
            this.degreesButton.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.degreesButton.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.degreesButton.Location = new System.Drawing.Point(736, 296);
            this.degreesButton.Name = "degreesButton";
            this.degreesButton.Size = new System.Drawing.Size(77, 25);
            this.degreesButton.TabIndex = 111;
            this.degreesButton.Text = "Degrees";
            this.degreesButton.Click += new System.EventHandler(this.degreesButton_Click);
            // 
            // specialistOnButton
            // 
            this.specialistOnButton.AutoSize = true;
            this.specialistOnButton.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.specialistOnButton.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.specialistOnButton.Location = new System.Drawing.Point(736, 260);
            this.specialistOnButton.Name = "specialistOnButton";
            this.specialistOnButton.Size = new System.Drawing.Size(114, 25);
            this.specialistOnButton.TabIndex = 110;
            this.specialistOnButton.Text = "Specialist On";
            this.specialistOnButton.Click += new System.EventHandler(this.specialistOnButton_Click);
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.Image = null;
            this.metroTextBox1.CustomButton.Location = new System.Drawing.Point(48, 2);
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = new System.Drawing.Size(105, 105);
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = 1;
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = false;
            this.metroTextBox1.Lines = new string[0];
            this.metroTextBox1.Location = new System.Drawing.Point(736, 139);
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ReadOnly = true;
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.Size = new System.Drawing.Size(156, 110);
            this.metroTextBox1.Style = MetroFramework.MetroColorStyle.Green;
            this.metroTextBox1.TabIndex = 109;
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel11.Location = new System.Drawing.Point(289, 296);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(82, 25);
            this.metroLabel11.TabIndex = 108;
            this.metroLabel11.Text = "Personal:";
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel14.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel14.Location = new System.Drawing.Point(306, 260);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(65, 25);
            this.metroLabel14.TabIndex = 107;
            this.metroLabel14.Text = "Home:";
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel15.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel15.Location = new System.Drawing.Point(303, 224);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(68, 25);
            this.metroLabel15.TabIndex = 106;
            this.metroLabel15.Text = "Office: ";
            // 
            // RoomWordLabel
            // 
            this.RoomWordLabel.AutoSize = true;
            this.RoomWordLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.RoomWordLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.RoomWordLabel.Location = new System.Drawing.Point(736, 106);
            this.RoomWordLabel.Name = "RoomWordLabel";
            this.RoomWordLabel.Size = new System.Drawing.Size(95, 25);
            this.RoomWordLabel.TabIndex = 105;
            this.RoomWordLabel.Text = "roomward";
            // 
            // DutyTimeLabel
            // 
            this.DutyTimeLabel.AutoSize = true;
            this.DutyTimeLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.DutyTimeLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.DutyTimeLabel.Location = new System.Drawing.Point(736, 73);
            this.DutyTimeLabel.Name = "DutyTimeLabel";
            this.DutyTimeLabel.Size = new System.Drawing.Size(83, 25);
            this.DutyTimeLabel.TabIndex = 104;
            this.DutyTimeLabel.Text = "dutytime";
            // 
            // DesignationLabel
            // 
            this.DesignationLabel.AutoSize = true;
            this.DesignationLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.DesignationLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.DesignationLabel.Location = new System.Drawing.Point(736, 40);
            this.DesignationLabel.Name = "DesignationLabel";
            this.DesignationLabel.Size = new System.Drawing.Size(105, 25);
            this.DesignationLabel.TabIndex = 103;
            this.DesignationLabel.Text = "designation";
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel13.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel13.Location = new System.Drawing.Point(603, 106);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(113, 25);
            this.metroLabel13.TabIndex = 102;
            this.metroLabel13.Text = "Room/Ward:";
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel12.Location = new System.Drawing.Point(635, 139);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(81, 25);
            this.metroLabel12.TabIndex = 101;
            this.metroLabel12.Text = "Address:";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel7.Location = new System.Drawing.Point(619, 73);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(97, 25);
            this.metroLabel7.TabIndex = 100;
            this.metroLabel7.Text = "Duty Time:";
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel10.Location = new System.Drawing.Point(605, 40);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(111, 25);
            this.metroLabel10.TabIndex = 99;
            this.metroLabel10.Text = "Designation:";
            // 
            // PersonalPhoneLabel
            // 
            this.PersonalPhoneLabel.AutoSize = true;
            this.PersonalPhoneLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.PersonalPhoneLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.PersonalPhoneLabel.Location = new System.Drawing.Point(376, 296);
            this.PersonalPhoneLabel.Name = "PersonalPhoneLabel";
            this.PersonalPhoneLabel.Size = new System.Drawing.Size(45, 25);
            this.PersonalPhoneLabel.TabIndex = 98;
            this.PersonalPhoneLabel.Text = "ppp";
            // 
            // HomePhoneLabel
            // 
            this.HomePhoneLabel.AutoSize = true;
            this.HomePhoneLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.HomePhoneLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.HomePhoneLabel.Location = new System.Drawing.Point(376, 260);
            this.HomePhoneLabel.Name = "HomePhoneLabel";
            this.HomePhoneLabel.Size = new System.Drawing.Size(42, 25);
            this.HomePhoneLabel.TabIndex = 97;
            this.HomePhoneLabel.Text = "hhh";
            // 
            // DateOfBirthLabel
            // 
            this.DateOfBirthLabel.AutoSize = true;
            this.DateOfBirthLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.DateOfBirthLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.DateOfBirthLabel.Location = new System.Drawing.Point(377, 139);
            this.DateOfBirthLabel.Name = "DateOfBirthLabel";
            this.DateOfBirthLabel.Size = new System.Drawing.Size(101, 25);
            this.DateOfBirthLabel.TabIndex = 96;
            this.DateOfBirthLabel.Text = "dateofbirth";
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel8.Location = new System.Drawing.Point(377, 332);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(54, 25);
            this.metroLabel8.TabIndex = 95;
            this.metroLabel8.Text = "email";
            // 
            // UserNameLabel
            // 
            this.UserNameLabel.AutoSize = true;
            this.UserNameLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.UserNameLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.UserNameLabel.Location = new System.Drawing.Point(376, 40);
            this.UserNameLabel.Name = "UserNameLabel";
            this.UserNameLabel.Size = new System.Drawing.Size(89, 25);
            this.UserNameLabel.TabIndex = 94;
            this.UserNameLabel.Text = "username";
            // 
            // OfficePhoneLabel
            // 
            this.OfficePhoneLabel.AutoSize = true;
            this.OfficePhoneLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.OfficePhoneLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.OfficePhoneLabel.Location = new System.Drawing.Point(376, 224);
            this.OfficePhoneLabel.Name = "OfficePhoneLabel";
            this.OfficePhoneLabel.Size = new System.Drawing.Size(34, 25);
            this.OfficePhoneLabel.TabIndex = 93;
            this.OfficePhoneLabel.Text = "oo";
            // 
            // GenderLabel
            // 
            this.GenderLabel.AutoSize = true;
            this.GenderLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.GenderLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.GenderLabel.Location = new System.Drawing.Point(377, 172);
            this.GenderLabel.Name = "GenderLabel";
            this.GenderLabel.Size = new System.Drawing.Size(68, 25);
            this.GenderLabel.TabIndex = 92;
            this.GenderLabel.Text = "gender";
            // 
            // LastNameLabel
            // 
            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.LastNameLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.LastNameLabel.Location = new System.Drawing.Point(377, 106);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(83, 25);
            this.LastNameLabel.TabIndex = 91;
            this.LastNameLabel.Text = "lastname";
            // 
            // FirstNameLabel
            // 
            this.FirstNameLabel.AutoSize = true;
            this.FirstNameLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.FirstNameLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.FirstNameLabel.Location = new System.Drawing.Point(377, 73);
            this.FirstNameLabel.Name = "FirstNameLabel";
            this.FirstNameLabel.Size = new System.Drawing.Size(86, 25);
            this.FirstNameLabel.TabIndex = 90;
            this.FirstNameLabel.Text = "firstname";
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel9.Location = new System.Drawing.Point(255, 139);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(116, 25);
            this.metroLabel9.TabIndex = 89;
            this.metroLabel9.Text = "Date of Birth:";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(313, 332);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(58, 25);
            this.metroLabel6.TabIndex = 88;
            this.metroLabel6.Text = "Email:";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(275, 40);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(95, 25);
            this.metroLabel5.TabIndex = 87;
            this.metroLabel5.Text = "Username:";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(255, 199);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(66, 25);
            this.metroLabel4.TabIndex = 86;
            this.metroLabel4.Text = "Phone:";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(298, 172);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(73, 25);
            this.metroLabel3.TabIndex = 85;
            this.metroLabel3.Text = "Gender:";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(272, 106);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(99, 25);
            this.metroLabel2.TabIndex = 84;
            this.metroLabel2.Text = "Last Name:";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(270, 73);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(101, 25);
            this.metroLabel1.TabIndex = 83;
            this.metroLabel1.Text = "First Name:";
            // 
            // doctorProfileUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.metroPanel1);
            this.Name = "doctorProfileUserControl";
            this.Size = new System.Drawing.Size(1148, 552);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel RoomWordLabel;
        private MetroFramework.Controls.MetroLabel DutyTimeLabel;
        private MetroFramework.Controls.MetroLabel DesignationLabel;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel PersonalPhoneLabel;
        private MetroFramework.Controls.MetroLabel HomePhoneLabel;
        private MetroFramework.Controls.MetroLabel DateOfBirthLabel;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel UserNameLabel;
        private MetroFramework.Controls.MetroLabel OfficePhoneLabel;
        private MetroFramework.Controls.MetroLabel GenderLabel;
        private MetroFramework.Controls.MetroLabel LastNameLabel;
        private MetroFramework.Controls.MetroLabel FirstNameLabel;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel degreesButton;
        private MetroFramework.Controls.MetroLabel specialistOnButton;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel metroLabel16;

    }
}
