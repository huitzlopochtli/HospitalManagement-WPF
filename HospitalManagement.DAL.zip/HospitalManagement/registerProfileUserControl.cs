﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalManagement
{
    public partial class registerProfileUserControl : UserControl
    {
        public registerProfileUserControl()
        {
            InitializeComponent();
        }

        private void UserNameLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
