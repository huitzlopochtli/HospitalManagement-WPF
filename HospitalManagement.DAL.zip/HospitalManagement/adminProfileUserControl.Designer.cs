﻿namespace HospitalManagement
{
    partial class adminProfileUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.DateOfBirthLabel = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.UserNameLabel = new MetroFramework.Controls.MetroLabel();
            this.OfficePhoneLabel = new MetroFramework.Controls.MetroLabel();
            this.GenderLabel = new MetroFramework.Controls.MetroLabel();
            this.LastNameLabel = new MetroFramework.Controls.MetroLabel();
            this.FirstNameLabel = new MetroFramework.Controls.MetroLabel();
            this.HomePhoneLabel = new MetroFramework.Controls.MetroLabel();
            this.PersonalPhoneLabel = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.RoomWordLabel = new MetroFramework.Controls.MetroLabel();
            this.DutyTimeLabel = new MetroFramework.Controls.MetroLabel();
            this.DesignationLabel = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.SuspendLayout();
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel9.Location = new System.Drawing.Point(254, 148);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(116, 25);
            this.metroLabel9.TabIndex = 34;
            this.metroLabel9.Text = "Date of Birth:";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(312, 343);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(58, 25);
            this.metroLabel6.TabIndex = 33;
            this.metroLabel6.Text = "Email:";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(275, 40);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(95, 25);
            this.metroLabel5.TabIndex = 32;
            this.metroLabel5.Text = "Username:";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(268, 213);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(66, 25);
            this.metroLabel4.TabIndex = 31;
            this.metroLabel4.Text = "Phone:";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(297, 184);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(73, 25);
            this.metroLabel3.TabIndex = 30;
            this.metroLabel3.Text = "Gender:";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(271, 112);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(99, 25);
            this.metroLabel2.TabIndex = 29;
            this.metroLabel2.Text = "Last Name:";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(269, 76);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(101, 25);
            this.metroLabel1.TabIndex = 28;
            this.metroLabel1.Text = "First Name:";
            // 
            // DateOfBirthLabel
            // 
            this.DateOfBirthLabel.AutoSize = true;
            this.DateOfBirthLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.DateOfBirthLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.DateOfBirthLabel.Location = new System.Drawing.Point(376, 148);
            this.DateOfBirthLabel.Name = "DateOfBirthLabel";
            this.DateOfBirthLabel.Size = new System.Drawing.Size(101, 25);
            this.DateOfBirthLabel.TabIndex = 41;
            this.DateOfBirthLabel.Text = "dateofbirth";
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel8.Location = new System.Drawing.Point(376, 343);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(54, 25);
            this.metroLabel8.TabIndex = 40;
            this.metroLabel8.Text = "email";
            // 
            // UserNameLabel
            // 
            this.UserNameLabel.AutoSize = true;
            this.UserNameLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.UserNameLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.UserNameLabel.Location = new System.Drawing.Point(376, 40);
            this.UserNameLabel.Name = "UserNameLabel";
            this.UserNameLabel.Size = new System.Drawing.Size(89, 25);
            this.UserNameLabel.TabIndex = 39;
            this.UserNameLabel.Text = "username";
            // 
            // OfficePhoneLabel
            // 
            this.OfficePhoneLabel.AutoSize = true;
            this.OfficePhoneLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.OfficePhoneLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.OfficePhoneLabel.Location = new System.Drawing.Point(376, 238);
            this.OfficePhoneLabel.Name = "OfficePhoneLabel";
            this.OfficePhoneLabel.Size = new System.Drawing.Size(34, 25);
            this.OfficePhoneLabel.TabIndex = 38;
            this.OfficePhoneLabel.Text = "oo";
            // 
            // GenderLabel
            // 
            this.GenderLabel.AutoSize = true;
            this.GenderLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.GenderLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.GenderLabel.Location = new System.Drawing.Point(376, 184);
            this.GenderLabel.Name = "GenderLabel";
            this.GenderLabel.Size = new System.Drawing.Size(68, 25);
            this.GenderLabel.TabIndex = 37;
            this.GenderLabel.Text = "gender";
            // 
            // LastNameLabel
            // 
            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.LastNameLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.LastNameLabel.Location = new System.Drawing.Point(376, 112);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(83, 25);
            this.LastNameLabel.TabIndex = 36;
            this.LastNameLabel.Text = "lastname";
            // 
            // FirstNameLabel
            // 
            this.FirstNameLabel.AutoSize = true;
            this.FirstNameLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.FirstNameLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.FirstNameLabel.Location = new System.Drawing.Point(376, 76);
            this.FirstNameLabel.Name = "FirstNameLabel";
            this.FirstNameLabel.Size = new System.Drawing.Size(86, 25);
            this.FirstNameLabel.TabIndex = 35;
            this.FirstNameLabel.Text = "firstname";
            // 
            // HomePhoneLabel
            // 
            this.HomePhoneLabel.AutoSize = true;
            this.HomePhoneLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.HomePhoneLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.HomePhoneLabel.Location = new System.Drawing.Point(376, 273);
            this.HomePhoneLabel.Name = "HomePhoneLabel";
            this.HomePhoneLabel.Size = new System.Drawing.Size(42, 25);
            this.HomePhoneLabel.TabIndex = 42;
            this.HomePhoneLabel.Text = "hhh";
            // 
            // PersonalPhoneLabel
            // 
            this.PersonalPhoneLabel.AutoSize = true;
            this.PersonalPhoneLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.PersonalPhoneLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.PersonalPhoneLabel.Location = new System.Drawing.Point(376, 308);
            this.PersonalPhoneLabel.Name = "PersonalPhoneLabel";
            this.PersonalPhoneLabel.Size = new System.Drawing.Size(45, 25);
            this.PersonalPhoneLabel.TabIndex = 43;
            this.PersonalPhoneLabel.Text = "ppp";
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel13.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel13.Location = new System.Drawing.Point(658, 112);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(113, 25);
            this.metroLabel13.TabIndex = 47;
            this.metroLabel13.Text = "Room/Ward:";
            this.metroLabel13.Click += new System.EventHandler(this.metroLabel13_Click);
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel12.Location = new System.Drawing.Point(690, 148);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(81, 25);
            this.metroLabel12.TabIndex = 46;
            this.metroLabel12.Text = "Address:";
            this.metroLabel12.Click += new System.EventHandler(this.metroLabel12_Click);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel7.Location = new System.Drawing.Point(674, 76);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(97, 25);
            this.metroLabel7.TabIndex = 45;
            this.metroLabel7.Text = "Duty Time:";
            this.metroLabel7.Click += new System.EventHandler(this.metroLabel7_Click);
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel10.Location = new System.Drawing.Point(660, 40);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(111, 25);
            this.metroLabel10.TabIndex = 44;
            this.metroLabel10.Text = "Designation:";
            this.metroLabel10.Click += new System.EventHandler(this.metroLabel10_Click);
            // 
            // RoomWordLabel
            // 
            this.RoomWordLabel.AutoSize = true;
            this.RoomWordLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.RoomWordLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.RoomWordLabel.Location = new System.Drawing.Point(787, 112);
            this.RoomWordLabel.Name = "RoomWordLabel";
            this.RoomWordLabel.Size = new System.Drawing.Size(95, 25);
            this.RoomWordLabel.TabIndex = 51;
            this.RoomWordLabel.Text = "roomward";
            this.RoomWordLabel.Click += new System.EventHandler(this.RoomWordLabel_Click);
            // 
            // DutyTimeLabel
            // 
            this.DutyTimeLabel.AutoSize = true;
            this.DutyTimeLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.DutyTimeLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.DutyTimeLabel.Location = new System.Drawing.Point(787, 76);
            this.DutyTimeLabel.Name = "DutyTimeLabel";
            this.DutyTimeLabel.Size = new System.Drawing.Size(83, 25);
            this.DutyTimeLabel.TabIndex = 49;
            this.DutyTimeLabel.Text = "dutytime";
            this.DutyTimeLabel.Click += new System.EventHandler(this.DutyTimeLabel_Click);
            // 
            // DesignationLabel
            // 
            this.DesignationLabel.AutoSize = true;
            this.DesignationLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.DesignationLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.DesignationLabel.Location = new System.Drawing.Point(787, 40);
            this.DesignationLabel.Name = "DesignationLabel";
            this.DesignationLabel.Size = new System.Drawing.Size(105, 25);
            this.DesignationLabel.TabIndex = 48;
            this.DesignationLabel.Text = "designation";
            this.DesignationLabel.Click += new System.EventHandler(this.DesignationLabel_Click);
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel11.Location = new System.Drawing.Point(288, 308);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(82, 25);
            this.metroLabel11.TabIndex = 54;
            this.metroLabel11.Text = "Personal:";
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel14.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel14.Location = new System.Drawing.Point(305, 273);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(65, 25);
            this.metroLabel14.TabIndex = 53;
            this.metroLabel14.Text = "Home:";
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel15.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel15.Location = new System.Drawing.Point(302, 238);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(68, 25);
            this.metroLabel15.TabIndex = 52;
            this.metroLabel15.Text = "Office: ";
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.Image = null;
            this.metroTextBox1.CustomButton.Location = new System.Drawing.Point(22, 2);
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = new System.Drawing.Size(105, 105);
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = 1;
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = false;
            this.metroTextBox1.Lines = new string[0];
            this.metroTextBox1.Location = new System.Drawing.Point(787, 153);
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ReadOnly = true;
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.Size = new System.Drawing.Size(130, 110);
            this.metroTextBox1.Style = MetroFramework.MetroColorStyle.Green;
            this.metroTextBox1.TabIndex = 55;
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox1.Click += new System.EventHandler(this.metroTextBox1_Click);
            // 
            // adminProfileUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.metroTextBox1);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.metroLabel14);
            this.Controls.Add(this.metroLabel15);
            this.Controls.Add(this.RoomWordLabel);
            this.Controls.Add(this.DutyTimeLabel);
            this.Controls.Add(this.DesignationLabel);
            this.Controls.Add(this.metroLabel13);
            this.Controls.Add(this.metroLabel12);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel10);
            this.Controls.Add(this.PersonalPhoneLabel);
            this.Controls.Add(this.HomePhoneLabel);
            this.Controls.Add(this.DateOfBirthLabel);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.UserNameLabel);
            this.Controls.Add(this.OfficePhoneLabel);
            this.Controls.Add(this.GenderLabel);
            this.Controls.Add(this.LastNameLabel);
            this.Controls.Add(this.FirstNameLabel);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Name = "adminProfileUserControl";
            this.Size = new System.Drawing.Size(1148, 552);
            this.Load += new System.EventHandler(this.adminProfileUserControl_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel DateOfBirthLabel;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel UserNameLabel;
        private MetroFramework.Controls.MetroLabel OfficePhoneLabel;
        private MetroFramework.Controls.MetroLabel GenderLabel;
        private MetroFramework.Controls.MetroLabel LastNameLabel;
        private MetroFramework.Controls.MetroLabel FirstNameLabel;
        private MetroFramework.Controls.MetroLabel HomePhoneLabel;
        private MetroFramework.Controls.MetroLabel PersonalPhoneLabel;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel RoomWordLabel;
        private MetroFramework.Controls.MetroLabel DutyTimeLabel;
        private MetroFramework.Controls.MetroLabel DesignationLabel;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;

    }
}
