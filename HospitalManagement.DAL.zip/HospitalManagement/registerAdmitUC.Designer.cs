﻿namespace HospitalManagement
{
    partial class registerAdmitUC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.searchTextBox = new MetroFramework.Controls.MetroTextBox();
            this.fNameTextBox = new MetroFramework.Controls.MetroTextBox();
            this.lNameTextBox = new MetroFramework.Controls.MetroTextBox();
            this.ageText = new MetroFramework.Controls.MetroTextBox();
            this.emailTextBox = new MetroFramework.Controls.MetroTextBox();
            this.addressTextBox = new MetroFramework.Controls.MetroTextBox();
            this.problemsTextBox = new MetroFramework.Controls.MetroTextBox();
            this.contactTextBox = new MetroFramework.Controls.MetroTextBox();
            this.sexComboBox = new MetroFramework.Controls.MetroComboBox();
            this.bloodGroupComboBox = new MetroFramework.Controls.MetroComboBox();
            this.IsPositiveComboBox = new MetroFramework.Controls.MetroComboBox();
            this.clearButton = new MetroFramework.Controls.MetroButton();
            this.ConfirmPrintButton = new MetroFramework.Controls.MetroButton();
            this.prefferedDoctorComboBox = new MetroFramework.Controls.MetroComboBox();
            this.dobDateTime = new MetroFramework.Controls.MetroDateTime();
            this.cancelmetroButton = new MetroFramework.Controls.MetroButton();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroComboBox1 = new MetroFramework.Controls.MetroComboBox();
            this.metroComboBox2 = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox3 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel2
            // 
            this.metroPanel2.Controls.Add(this.metroLabel13);
            this.metroPanel2.Controls.Add(this.metroTextBox3);
            this.metroPanel2.Controls.Add(this.metroLabel14);
            this.metroPanel2.Controls.Add(this.metroLabel15);
            this.metroPanel2.Controls.Add(this.cancelmetroButton);
            this.metroPanel2.Controls.Add(this.dobDateTime);
            this.metroPanel2.Controls.Add(this.metroComboBox2);
            this.metroPanel2.Controls.Add(this.metroComboBox1);
            this.metroPanel2.Controls.Add(this.prefferedDoctorComboBox);
            this.metroPanel2.Controls.Add(this.ConfirmPrintButton);
            this.metroPanel2.Controls.Add(this.clearButton);
            this.metroPanel2.Controls.Add(this.IsPositiveComboBox);
            this.metroPanel2.Controls.Add(this.bloodGroupComboBox);
            this.metroPanel2.Controls.Add(this.sexComboBox);
            this.metroPanel2.Controls.Add(this.contactTextBox);
            this.metroPanel2.Controls.Add(this.problemsTextBox);
            this.metroPanel2.Controls.Add(this.addressTextBox);
            this.metroPanel2.Controls.Add(this.emailTextBox);
            this.metroPanel2.Controls.Add(this.ageText);
            this.metroPanel2.Controls.Add(this.lNameTextBox);
            this.metroPanel2.Controls.Add(this.fNameTextBox);
            this.metroPanel2.Controls.Add(this.searchTextBox);
            this.metroPanel2.Controls.Add(this.metroLabel12);
            this.metroPanel2.Controls.Add(this.metroLabel11);
            this.metroPanel2.Controls.Add(this.metroLabel10);
            this.metroPanel2.Controls.Add(this.metroLabel9);
            this.metroPanel2.Controls.Add(this.metroLabel8);
            this.metroPanel2.Controls.Add(this.metroLabel6);
            this.metroPanel2.Controls.Add(this.metroLabel5);
            this.metroPanel2.Controls.Add(this.metroLabel7);
            this.metroPanel2.Controls.Add(this.metroLabel3);
            this.metroPanel2.Controls.Add(this.metroLabel4);
            this.metroPanel2.Controls.Add(this.metroLabel2);
            this.metroPanel2.Controls.Add(this.metroLabel1);
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(0, 0);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(500, 700);
            this.metroPanel2.TabIndex = 2;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(79, 45);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(101, 25);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "First Name:";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(79, 79);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(99, 25);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Last Name:";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(107, 147);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(73, 25);
            this.metroLabel4.TabIndex = 2;
            this.metroLabel4.Text = "Gender:";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(12, 113);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(168, 25);
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Date Of Birth / Age:";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel7.Location = new System.Drawing.Point(122, 249);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(58, 25);
            this.metroLabel7.TabIndex = 2;
            this.metroLabel7.Text = "Email:";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(62, 181);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(118, 25);
            this.metroLabel5.TabIndex = 3;
            this.metroLabel5.Text = "Blood Group:";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(103, 215);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(77, 25);
            this.metroLabel6.TabIndex = 4;
            this.metroLabel6.Text = "Contact:";
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel8.Location = new System.Drawing.Point(99, 274);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(81, 25);
            this.metroLabel8.TabIndex = 3;
            this.metroLabel8.Text = "Address:";
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel9.Location = new System.Drawing.Point(90, 373);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(91, 25);
            this.metroLabel9.TabIndex = 4;
            this.metroLabel9.Text = "Problems:";
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel10.Location = new System.Drawing.Point(32, 398);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(148, 25);
            this.metroLabel10.TabIndex = 4;
            this.metroLabel10.Text = "Preffered Doctor:";
            this.metroLabel10.Click += new System.EventHandler(this.metroLabel10_Click);
            // 
            // searchTextBox
            // 
            // 
            // 
            // 
            this.searchTextBox.CustomButton.Image = null;
            this.searchTextBox.CustomButton.Location = new System.Drawing.Point(193, 1);
            this.searchTextBox.CustomButton.Name = "";
            this.searchTextBox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.searchTextBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.searchTextBox.CustomButton.TabIndex = 1;
            this.searchTextBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.searchTextBox.CustomButton.UseSelectable = true;
            this.searchTextBox.CustomButton.Visible = false;
            this.searchTextBox.Lines = new string[0];
            this.searchTextBox.Location = new System.Drawing.Point(107, 3);
            this.searchTextBox.MaxLength = 32767;
            this.searchTextBox.Name = "searchTextBox";
            this.searchTextBox.PasswordChar = '\0';
            this.searchTextBox.PromptText = "Search";
            this.searchTextBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.searchTextBox.SelectedText = "";
            this.searchTextBox.SelectionLength = 0;
            this.searchTextBox.SelectionStart = 0;
            this.searchTextBox.ShortcutsEnabled = true;
            this.searchTextBox.Size = new System.Drawing.Size(215, 23);
            this.searchTextBox.TabIndex = 5;
            this.searchTextBox.UseSelectable = true;
            this.searchTextBox.WaterMark = "Search";
            this.searchTextBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.searchTextBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // fNameTextBox
            // 
            // 
            // 
            // 
            this.fNameTextBox.CustomButton.Image = null;
            this.fNameTextBox.CustomButton.Location = new System.Drawing.Point(111, 1);
            this.fNameTextBox.CustomButton.Name = "";
            this.fNameTextBox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.fNameTextBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.fNameTextBox.CustomButton.TabIndex = 1;
            this.fNameTextBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.fNameTextBox.CustomButton.UseSelectable = true;
            this.fNameTextBox.CustomButton.Visible = false;
            this.fNameTextBox.Lines = new string[] {
        "a"};
            this.fNameTextBox.Location = new System.Drawing.Point(247, 47);
            this.fNameTextBox.MaxLength = 32767;
            this.fNameTextBox.Name = "fNameTextBox";
            this.fNameTextBox.PasswordChar = '\0';
            this.fNameTextBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.fNameTextBox.SelectedText = "";
            this.fNameTextBox.SelectionLength = 0;
            this.fNameTextBox.SelectionStart = 0;
            this.fNameTextBox.ShortcutsEnabled = true;
            this.fNameTextBox.Size = new System.Drawing.Size(133, 23);
            this.fNameTextBox.TabIndex = 6;
            this.fNameTextBox.Text = "a";
            this.fNameTextBox.UseSelectable = true;
            this.fNameTextBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.fNameTextBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lNameTextBox
            // 
            // 
            // 
            // 
            this.lNameTextBox.CustomButton.Image = null;
            this.lNameTextBox.CustomButton.Location = new System.Drawing.Point(111, 1);
            this.lNameTextBox.CustomButton.Name = "";
            this.lNameTextBox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.lNameTextBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.lNameTextBox.CustomButton.TabIndex = 1;
            this.lNameTextBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.lNameTextBox.CustomButton.UseSelectable = true;
            this.lNameTextBox.CustomButton.Visible = false;
            this.lNameTextBox.Lines = new string[] {
        "b"};
            this.lNameTextBox.Location = new System.Drawing.Point(247, 77);
            this.lNameTextBox.MaxLength = 32767;
            this.lNameTextBox.Name = "lNameTextBox";
            this.lNameTextBox.PasswordChar = '\0';
            this.lNameTextBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.lNameTextBox.SelectedText = "";
            this.lNameTextBox.SelectionLength = 0;
            this.lNameTextBox.SelectionStart = 0;
            this.lNameTextBox.ShortcutsEnabled = true;
            this.lNameTextBox.Size = new System.Drawing.Size(133, 23);
            this.lNameTextBox.TabIndex = 6;
            this.lNameTextBox.Text = "b";
            this.lNameTextBox.UseSelectable = true;
            this.lNameTextBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.lNameTextBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // ageText
            // 
            // 
            // 
            // 
            this.ageText.CustomButton.Image = null;
            this.ageText.CustomButton.Location = new System.Drawing.Point(24, 1);
            this.ageText.CustomButton.Name = "";
            this.ageText.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.ageText.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.ageText.CustomButton.TabIndex = 1;
            this.ageText.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.ageText.CustomButton.UseSelectable = true;
            this.ageText.CustomButton.Visible = false;
            this.ageText.Lines = new string[] {
        "c"};
            this.ageText.Location = new System.Drawing.Point(328, 106);
            this.ageText.MaxLength = 32767;
            this.ageText.Name = "ageText";
            this.ageText.PasswordChar = '\0';
            this.ageText.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.ageText.SelectedText = "";
            this.ageText.SelectionLength = 0;
            this.ageText.SelectionStart = 0;
            this.ageText.ShortcutsEnabled = true;
            this.ageText.Size = new System.Drawing.Size(52, 29);
            this.ageText.TabIndex = 6;
            this.ageText.Text = "c";
            this.ageText.UseSelectable = true;
            this.ageText.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.ageText.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // emailTextBox
            // 
            // 
            // 
            // 
            this.emailTextBox.CustomButton.Image = null;
            this.emailTextBox.CustomButton.Location = new System.Drawing.Point(111, 1);
            this.emailTextBox.CustomButton.Name = "";
            this.emailTextBox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.emailTextBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.emailTextBox.CustomButton.TabIndex = 1;
            this.emailTextBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.emailTextBox.CustomButton.UseSelectable = true;
            this.emailTextBox.CustomButton.Visible = false;
            this.emailTextBox.Lines = new string[] {
        "e"};
            this.emailTextBox.Location = new System.Drawing.Point(247, 245);
            this.emailTextBox.MaxLength = 32767;
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.PasswordChar = '\0';
            this.emailTextBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.emailTextBox.SelectedText = "";
            this.emailTextBox.SelectionLength = 0;
            this.emailTextBox.SelectionStart = 0;
            this.emailTextBox.ShortcutsEnabled = true;
            this.emailTextBox.Size = new System.Drawing.Size(133, 23);
            this.emailTextBox.TabIndex = 6;
            this.emailTextBox.Text = "e";
            this.emailTextBox.UseSelectable = true;
            this.emailTextBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.emailTextBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // addressTextBox
            // 
            // 
            // 
            // 
            this.addressTextBox.CustomButton.Image = null;
            this.addressTextBox.CustomButton.Location = new System.Drawing.Point(41, 1);
            this.addressTextBox.CustomButton.Name = "";
            this.addressTextBox.CustomButton.Size = new System.Drawing.Size(91, 91);
            this.addressTextBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.addressTextBox.CustomButton.TabIndex = 1;
            this.addressTextBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.addressTextBox.CustomButton.UseSelectable = true;
            this.addressTextBox.CustomButton.Visible = false;
            this.addressTextBox.Lines = new string[] {
        "f"};
            this.addressTextBox.Location = new System.Drawing.Point(247, 274);
            this.addressTextBox.MaxLength = 32767;
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.PasswordChar = '\0';
            this.addressTextBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.addressTextBox.SelectedText = "";
            this.addressTextBox.SelectionLength = 0;
            this.addressTextBox.SelectionStart = 0;
            this.addressTextBox.ShortcutsEnabled = true;
            this.addressTextBox.Size = new System.Drawing.Size(133, 93);
            this.addressTextBox.TabIndex = 6;
            this.addressTextBox.Text = "f";
            this.addressTextBox.UseSelectable = true;
            this.addressTextBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.addressTextBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.addressTextBox.Click += new System.EventHandler(this.addressTextBox_Click);
            // 
            // problemsTextBox
            // 
            // 
            // 
            // 
            this.problemsTextBox.CustomButton.Image = null;
            this.problemsTextBox.CustomButton.Location = new System.Drawing.Point(111, 1);
            this.problemsTextBox.CustomButton.Name = "";
            this.problemsTextBox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.problemsTextBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.problemsTextBox.CustomButton.TabIndex = 1;
            this.problemsTextBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.problemsTextBox.CustomButton.UseSelectable = true;
            this.problemsTextBox.CustomButton.Visible = false;
            this.problemsTextBox.Lines = new string[] {
        "p"};
            this.problemsTextBox.Location = new System.Drawing.Point(247, 373);
            this.problemsTextBox.MaxLength = 32767;
            this.problemsTextBox.Name = "problemsTextBox";
            this.problemsTextBox.PasswordChar = '\0';
            this.problemsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.problemsTextBox.SelectedText = "";
            this.problemsTextBox.SelectionLength = 0;
            this.problemsTextBox.SelectionStart = 0;
            this.problemsTextBox.ShortcutsEnabled = true;
            this.problemsTextBox.Size = new System.Drawing.Size(133, 23);
            this.problemsTextBox.TabIndex = 6;
            this.problemsTextBox.Text = "p";
            this.problemsTextBox.UseSelectable = true;
            this.problemsTextBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.problemsTextBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // contactTextBox
            // 
            // 
            // 
            // 
            this.contactTextBox.CustomButton.Image = null;
            this.contactTextBox.CustomButton.Location = new System.Drawing.Point(111, 1);
            this.contactTextBox.CustomButton.Name = "";
            this.contactTextBox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.contactTextBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.contactTextBox.CustomButton.TabIndex = 1;
            this.contactTextBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.contactTextBox.CustomButton.UseSelectable = true;
            this.contactTextBox.CustomButton.Visible = false;
            this.contactTextBox.Lines = new string[] {
        "d"};
            this.contactTextBox.Location = new System.Drawing.Point(247, 215);
            this.contactTextBox.MaxLength = 32767;
            this.contactTextBox.Name = "contactTextBox";
            this.contactTextBox.PasswordChar = '\0';
            this.contactTextBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.contactTextBox.SelectedText = "";
            this.contactTextBox.SelectionLength = 0;
            this.contactTextBox.SelectionStart = 0;
            this.contactTextBox.ShortcutsEnabled = true;
            this.contactTextBox.Size = new System.Drawing.Size(133, 23);
            this.contactTextBox.TabIndex = 6;
            this.contactTextBox.Text = "d";
            this.contactTextBox.UseSelectable = true;
            this.contactTextBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.contactTextBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // sexComboBox
            // 
            this.sexComboBox.FormattingEnabled = true;
            this.sexComboBox.ItemHeight = 23;
            this.sexComboBox.Location = new System.Drawing.Point(247, 143);
            this.sexComboBox.Name = "sexComboBox";
            this.sexComboBox.Size = new System.Drawing.Size(75, 29);
            this.sexComboBox.TabIndex = 7;
            this.sexComboBox.UseSelectable = true;
            // 
            // bloodGroupComboBox
            // 
            this.bloodGroupComboBox.FormattingEnabled = true;
            this.bloodGroupComboBox.ItemHeight = 23;
            this.bloodGroupComboBox.Location = new System.Drawing.Point(247, 179);
            this.bloodGroupComboBox.Name = "bloodGroupComboBox";
            this.bloodGroupComboBox.Size = new System.Drawing.Size(75, 29);
            this.bloodGroupComboBox.TabIndex = 7;
            this.bloodGroupComboBox.UseSelectable = true;
            // 
            // IsPositiveComboBox
            // 
            this.IsPositiveComboBox.FormattingEnabled = true;
            this.IsPositiveComboBox.ItemHeight = 23;
            this.IsPositiveComboBox.Location = new System.Drawing.Point(328, 177);
            this.IsPositiveComboBox.Name = "IsPositiveComboBox";
            this.IsPositiveComboBox.Size = new System.Drawing.Size(75, 29);
            this.IsPositiveComboBox.TabIndex = 7;
            this.IsPositiveComboBox.UseSelectable = true;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(189, 621);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(128, 47);
            this.clearButton.TabIndex = 8;
            this.clearButton.Text = "Cancel";
            this.clearButton.UseSelectable = true;
            // 
            // ConfirmPrintButton
            // 
            this.ConfirmPrintButton.Location = new System.Drawing.Point(351, 621);
            this.ConfirmPrintButton.Name = "ConfirmPrintButton";
            this.ConfirmPrintButton.Size = new System.Drawing.Size(128, 47);
            this.ConfirmPrintButton.TabIndex = 8;
            this.ConfirmPrintButton.Text = "Confirm And Print";
            this.ConfirmPrintButton.UseSelectable = true;
            // 
            // prefferedDoctorComboBox
            // 
            this.prefferedDoctorComboBox.FormattingEnabled = true;
            this.prefferedDoctorComboBox.ItemHeight = 23;
            this.prefferedDoctorComboBox.Location = new System.Drawing.Point(242, 402);
            this.prefferedDoctorComboBox.Name = "prefferedDoctorComboBox";
            this.prefferedDoctorComboBox.Size = new System.Drawing.Size(192, 29);
            this.prefferedDoctorComboBox.TabIndex = 9;
            this.prefferedDoctorComboBox.UseSelectable = true;
            // 
            // dobDateTime
            // 
            this.dobDateTime.Location = new System.Drawing.Point(247, 107);
            this.dobDateTime.MinimumSize = new System.Drawing.Size(0, 29);
            this.dobDateTime.Name = "dobDateTime";
            this.dobDateTime.Size = new System.Drawing.Size(75, 29);
            this.dobDateTime.TabIndex = 10;
            // 
            // cancelmetroButton
            // 
            this.cancelmetroButton.Location = new System.Drawing.Point(32, 621);
            this.cancelmetroButton.Name = "cancelmetroButton";
            this.cancelmetroButton.Size = new System.Drawing.Size(128, 47);
            this.cancelmetroButton.TabIndex = 11;
            this.cancelmetroButton.Text = "Clear";
            this.cancelmetroButton.UseSelectable = true;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel11.Location = new System.Drawing.Point(70, 437);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(107, 25);
            this.metroLabel11.TabIndex = 4;
            this.metroLabel11.Text = "Admit Type:";
            this.metroLabel11.Click += new System.EventHandler(this.metroLabel10_Click);
            // 
            // metroComboBox1
            // 
            this.metroComboBox1.FormattingEnabled = true;
            this.metroComboBox1.ItemHeight = 23;
            this.metroComboBox1.Location = new System.Drawing.Point(242, 437);
            this.metroComboBox1.Name = "metroComboBox1";
            this.metroComboBox1.Size = new System.Drawing.Size(192, 29);
            this.metroComboBox1.TabIndex = 9;
            this.metroComboBox1.UseSelectable = true;
            // 
            // metroComboBox2
            // 
            this.metroComboBox2.FormattingEnabled = true;
            this.metroComboBox2.ItemHeight = 23;
            this.metroComboBox2.Location = new System.Drawing.Point(242, 473);
            this.metroComboBox2.Name = "metroComboBox2";
            this.metroComboBox2.Size = new System.Drawing.Size(75, 29);
            this.metroComboBox2.TabIndex = 9;
            this.metroComboBox2.UseSelectable = true;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel12.Location = new System.Drawing.Point(44, 473);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(134, 25);
            this.metroLabel12.TabIndex = 4;
            this.metroLabel12.Text = "Room Number:";
            this.metroLabel12.Click += new System.EventHandler(this.metroLabel10_Click);
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(242, 554);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(88, 19);
            this.metroLabel13.TabIndex = 15;
            this.metroLabel13.Text = "metroLabel13";
            this.metroLabel13.Click += new System.EventHandler(this.metroLabel13_Click);
            // 
            // metroTextBox3
            // 
            // 
            // 
            // 
            this.metroTextBox3.CustomButton.Image = null;
            this.metroTextBox3.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.metroTextBox3.CustomButton.Name = "";
            this.metroTextBox3.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox3.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox3.CustomButton.TabIndex = 1;
            this.metroTextBox3.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox3.CustomButton.UseSelectable = true;
            this.metroTextBox3.CustomButton.Visible = false;
            this.metroTextBox3.Lines = new string[] {
        "metroTextBox1"};
            this.metroTextBox3.Location = new System.Drawing.Point(242, 515);
            this.metroTextBox3.MaxLength = 32767;
            this.metroTextBox3.Name = "metroTextBox3";
            this.metroTextBox3.PasswordChar = '\0';
            this.metroTextBox3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox3.SelectedText = "";
            this.metroTextBox3.SelectionLength = 0;
            this.metroTextBox3.SelectionStart = 0;
            this.metroTextBox3.ShortcutsEnabled = true;
            this.metroTextBox3.Size = new System.Drawing.Size(200, 23);
            this.metroTextBox3.TabIndex = 14;
            this.metroTextBox3.Text = "metroTextBox1";
            this.metroTextBox3.UseSelectable = true;
            this.metroTextBox3.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox3.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel14.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel14.Location = new System.Drawing.Point(69, 513);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(111, 25);
            this.metroLabel14.TabIndex = 12;
            this.metroLabel14.Text = "Discount(%):";
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel15.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel15.Location = new System.Drawing.Point(79, 554);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(108, 25);
            this.metroLabel15.TabIndex = 13;
            this.metroLabel15.Text = "Fee per day:";
            // 
            // registerAdmitUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.metroPanel2);
            this.Name = "registerAdmitUC";
            this.Size = new System.Drawing.Size(500, 700);
            this.metroPanel2.ResumeLayout(false);
            this.metroPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel2;
        private MetroFramework.Controls.MetroButton cancelmetroButton;
        private MetroFramework.Controls.MetroDateTime dobDateTime;
        private MetroFramework.Controls.MetroComboBox prefferedDoctorComboBox;
        private MetroFramework.Controls.MetroButton ConfirmPrintButton;
        private MetroFramework.Controls.MetroButton clearButton;
        private MetroFramework.Controls.MetroComboBox IsPositiveComboBox;
        private MetroFramework.Controls.MetroComboBox bloodGroupComboBox;
        private MetroFramework.Controls.MetroComboBox sexComboBox;
        private MetroFramework.Controls.MetroTextBox contactTextBox;
        private MetroFramework.Controls.MetroTextBox problemsTextBox;
        private MetroFramework.Controls.MetroTextBox addressTextBox;
        private MetroFramework.Controls.MetroTextBox emailTextBox;
        private MetroFramework.Controls.MetroTextBox ageText;
        private MetroFramework.Controls.MetroTextBox lNameTextBox;
        private MetroFramework.Controls.MetroTextBox fNameTextBox;
        private MetroFramework.Controls.MetroTextBox searchTextBox;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroComboBox metroComboBox2;
        private MetroFramework.Controls.MetroComboBox metroComboBox1;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroTextBox metroTextBox3;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel15;

    }
}
